    // The test index:
    //       \ docId |  0  |  1  |  2  |
    //        \      |
    //   term  \     |  tf |  tf |  tf | df
    //   ---------------------------------------------------------
    //   another     |  0  |  1  |  0  | 1
    //   example     |  1  |  1  |  0  | 2
    //   funny       |  0  |  1  |  1  | 2
    //   just        |  0  |  0  |  1  | 1
    //   sentence    |  1  |  1  |  1  | 3
