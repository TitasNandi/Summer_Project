# adsabs-pyingest

A collection or python parsers, validators, and serializers for adsabs ingest pipeline.
For the time being all we have is simple stuff used to ingest data into ADS Classic, but
this is eant to grow and change in due time as our metadata models become more sophisticated.

